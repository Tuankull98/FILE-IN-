"""Giá đỡ jack GX12 có ren trong M12x1 - chạy: python gx12_threaded_mount.py"""
import cadquery as cq, math
from OCP.BRepBuilderAPI import BRepBuilderAPI_Sewing

# ================= THAM SỐ (mm) =================
CLEAR   = 0.30          # dung sai ren: chặt quá -> tăng 0.05-0.1, lỏng -> giảm
P       = 1.0           # bước ren GX12 = M12x1 (KHÔNG đổi, đổi là không vặn vào jack được)
D_MAJ   = 12.0 + CLEAR  # đáy rãnh ren trong (chỗ đỉnh ren jack chui vào)
D_MIN   = 10.9 + CLEAR  # đỉnh gờ ren trong
CREST   = 0.10          # nửa bề rộng đỉnh gờ ren (nhỏ = gờ nhọn, rãnh rõ)
ROOT    = 0.44          # nửa bề rộng chân gờ ren (tối đa < P/2)
SELF_TAP = False        # True = bỏ ren, để lỗ trơn Ø11.4 cho ren kim loại của jack tự cắt vào nhựa

BOSS_D  = 17.0          # đường kính ngoài cụm ren
BOSS_H  = 6.0           # chiều dài ren
TAB_T   = 3.0           # độ dày tai bắt vít
TAB_W   = 10.0          # bề rộng tai
TAB_L   = 16.0          # chiều dài tai
M3      = 3.3           # lỗ vít M3
# =================================================

def ridge(r_out, r_in, pitch, length, z0, a_in, a_out):
    """Gờ ren xoắn tiết diện thang, dựng từ 4 mặt kẻ giữa các đường helix."""
    hx = lambda r, dz: cq.Wire.makeHelix(pitch, length, r, center=cq.Vector(0, 0, z0 + dz))
    w = [hx(r_out, -a_out), hx(r_in, -a_in), hx(r_in, a_in), hx(r_out, a_out)]
    faces = [cq.Face.makeRuledSurface(w[i], w[(i + 1) % 4]) for i in range(4)]
    for end in ("startPoint", "endPoint"):
        faces.append(cq.Face.makeFromWires(cq.Wire.makePolygon([getattr(x, end)() for x in w], close=True)))
    sew = BRepBuilderAPI_Sewing(1e-4)
    for f in faces: sew.Add(f.wrapped)
    sew.Perform()
    return cq.Solid.makeSolid(cq.Shell(sew.SewedShape()))

boss = cq.Workplane("XY").circle(BOSS_D / 2).extrude(BOSS_H)
tab = (cq.Workplane("XY").center(TAB_L / 2 + 4, 0).rect(TAB_L, TAB_W).extrude(TAB_T)
       .edges("|Z and >X").fillet(TAB_W / 2 - 0.01))
body = boss.union(tab)
body = body.cut(cq.Workplane("XY").center(4 + TAB_L - TAB_W / 2, 0).circle(M3 / 2).extrude(TAB_T))

if SELF_TAP:
    body = body.cut(cq.Workplane("XY").circle(11.4 / 2).extrude(BOSS_H))
else:
    body = body.cut(cq.Workplane("XY").circle(D_MAJ / 2).extrude(BOSS_H))
    t = ridge(D_MAJ / 2 + 0.15, D_MIN / 2, P, BOSS_H + 4 * P, -2 * P, CREST, ROOT)
    t = cq.Workplane().add(t).intersect(cq.Workplane("XY").circle(D_MAJ / 2 + 0.5).extrude(BOSS_H))
    body = body.union(t, tol=1e-3)

# vát miệng lỗ hai đầu cho dễ ăn ren
body = body.cut(cq.Workplane().add(cq.Solid.makeCone(D_MAJ / 2 + 0.4, D_MIN / 2 - 0.2, 0.7)))
body = body.cut(cq.Workplane().add(cq.Solid.makeCone(D_MIN / 2 - 0.2, D_MAJ / 2 + 0.4, 0.7,
                                                     pnt=cq.Vector(0, 0, BOSS_H - 0.7))))

s = body.val()
print("valid:", s.isValid(), "| so khoi:", len(body.solids().vals()))
bb = s.BoundingBox(); print("kich thuoc:", round(bb.xlen, 1), round(bb.ylen, 1), round(bb.zlen, 1))
cq.exporters.export(body, "gx12_threaded_mount.step")
cq.exporters.export(body, "gx12_threaded_mount.stl", tolerance=0.01, angularTolerance=0.05)
